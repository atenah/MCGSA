## ----setup, message=FALSE, echo=FALSE------------------------------------
knitr::opts_chunk$set(echo = FALSE, message = FALSE,
  warning = FALSE)

library(knitr)
opts_knit$set(root.dir=normalizePath('../'))

## ------------------------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, message = FALSE,
  warning = FALSE)

library(MCGSA)
require(geosphere)
require(mvngGrAd)

## ----get_data------------------------------------------------------------
#set working directory to file where R script is located ########
###Read in the data, extract coordinates and phenotype###

dat = read.delim("~/MCGSA/data/data_irr.csv", sep=",")
Coords  = cbind(Long = dat$Long, Lat = dat$LAT)
obsPhe  = dat$Yield
toMerge = c("trial","Plot","Rep","SubBlock","Entry")

## ----sketch--------------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, message = FALSE,
  warning = FALSE)

circularSketch <- function(Coords, obsPhe, radius, chosenEntry, excludeCenter=TRUE){
  N    = nrow(Coords)
  idx  = 1:N
  dMat = sapply(idx, function(x) distHaversine(Coords, Coords[x,], r = 6378137))
  incl = 'if'(excludeCenter, sapply(idx, function(x) which(dMat[x,] <= radius  & idx!=x)),
              sapply(idx, function(x) which(dMat[x,] <= radius)))

  cols = rep("Black", N)
  cols[incl[[chosenEntry]]] = "Blue"
  cols[chosenEntry] = 'if'(excludeCenter, "Black", "Red")
  main = c(paste("Chosen:", chosenEntry),
           paste("Exclude Center:", excludeCenter),
           paste("Nval=", length(incl[[chosenEntry]])))
  plot(Coords, pch=16, col= cols, main=main)
  points(Coords[chosenEntry,, drop=F], pch=21, bg=cols[chosenEntry], col="Black", cex=1.25)
}

## ----CircularMoving------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, message = FALSE,
  warning = FALSE)

mcsa <- function(Coords, obsPhe, radius, excludeCenter=TRUE){
  N    = nrow(Coords)
  idx  = 1:N
  dMat = sapply(idx, function(x) distHaversine(Coords, Coords[x,], r = 6378137))
  incl = 'if'(excludeCenter, sapply(idx, function(x) which(dMat[x,] <= radius  & idx!=x)),
              sapply(idx, function(x) which(dMat[x,] <= radius)))

  xi   = sapply(idx, function(x) mean(obsPhe[incl[[x]]]))
  nVal = sapply(incl, length)

  b      = coef(lm(obsPhe ~ xi, na.action = "na.exclude"))[2]
  adjPhe = obsPhe - b*(xi - mean(xi, na.rm=T))
  ret    = cbind(Coords,
                 adjustedPhe = adjPhe,
                 observedPhe = obsPhe,
                 movingMean  = xi,
                 nValues     = nVal)
  return(ret)
}

## ----process-------------------------------------------------------------

# Plot all of the data coordinates and highlight those grouped together with a chosen one
library(MCGSA)
circularSketch(Coords = Coords, obsPhe = obsPhe, chosenEntry = 200, radius = 5, excludeCenter = TRUE)

# The "circular moving grid" function

res = mcsa(Coords = Coords, obsPhe = obsPhe, radius = 5, excludeCenter = T) 

# Save the output as a csv. The ID column is included.
#write.csv(cbind(dat[,colnames(dat) %in% toMerge], res), "Output_merged.csv", row.names=F)

