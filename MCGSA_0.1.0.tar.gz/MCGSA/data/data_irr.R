#' High Throughput Phenotyping values extracted from UAS and yield
#'
#' @source Data collected by Atena Haghighattalab using Unmanned Aerial System (UAS) in Summer 2016, CIMMYT, Mexico
#' @format A data frame with columns:
#' \describe{
#'  \item{Long}{Longitude of plots, extracted from aerial imagery}
#'  \item{LAT}{Lattitude of Plots, extracted from aerial imagery}
#'  \item{row}{The row number of plot's location based on the field map}
#'  \item{column}{The column number of plot's location based on the field map}
#'  \item{trial}{the number of trial that the plot belongs to.}
#'  \item{Plot}{Plot number.}
#'  \item{Rep}{number of replication.}
#'  \item{SubBlock}{number of sub-block based on the field design.}
#'  \item{Entry}{number of Entry that the plot belongs to.}
#'  \item{Germ}{measured germ value after harvest for the plot.}
#'  \item{Yield}{measured yield value after harvest for the plot.}
#'  \item{GNDVI_March10}{Green Normaliozed Vegetation Index, calculated on March 10, using aerial imagery.}
#'  \item{GNDVI_March15}{Green Normaliozed Vegetation Index, calculated on March 15, using aerial imagery.}
#'  \item{GNDVI_April8}{Green Normaliozed Vegetation Index, calculated on Aprl 8, using aerial imagery.}
#'  \item{UAS_Height}{Plant's height, extracted from degital elevation mlodel using the aerial imagery.}
#' }
#' @examples
#' \dontrun{
#'  Data_irrigated
#' }
"Data_irrigated"
