
#' "Circular Sketch"
#'\author{
#'  Atena Haghighattalab}
#'
#' This is a function that aids with grid design;
#' Plots all of the data coordinates and highlight those grouped together
#' with a chosen plot in the center of a circular grid.
#' This function take advantages of Haversine method, and calculates
#' the shortest distance between two plots (i.e., the 'great-circle-distance'),
#' according to the 'haversine method'.
#'The Haversine ('half-versed-sine') formula was published by R.W. Sinnott in 1984,
#'although it has been known for much longer. At that time computational precision
#'was lower than today (15 digits precision). With current precision,
#'the spherical law of cosines formula appears to give equally good results
#'down to very small distances. If you want greater accuracy,
#'you could use the distVincentyEllipsoid method.
#'{distVincentyEllipsoid(p1, p2, a=6378137, b=6356752.3142, f=1/298.257223563)}
#'
#'\usage{
#'circularSketch(Coords, obsPhe, chosenEntry, radius, excludeCenter = T)
#'}
#' @param Coords The coordinates of plots, in longitude and altitude format, In Coords using cbind we Combine the first two columns of the data
#' @param obsPhe The phenotyping observation
#' @param radius Defined radius in meter to draw the circular moving grid
#' @param chosenEntry The Entry number, that you want to draw the circular grid around,
#' for viualization purposes.
#'
#' @return Plots the data coordinates and selected neighbors
#'
#' @examples
#' library(MCGSA)
#'dat = read.delim()
#'Coords  = cbind(Long = dat$Long, Lat = dat$LAT)
#'obsPhe  = dat$Yield
#'circularSketch(Coords = Coords, obsPhe = obsPhe, chosenEntry = 200, radius = 5, excludeCenter = TRUE)
#'
#' @export

circularSketch <- function(Coords, obsPhe,chosenEntry, radius,excludeCenter=TRUE){
  N    = nrow(Coords)
  idx  = 1:N
  dMat = sapply(idx, function(x) distHaversine(Coords, Coords[x,], r = 6378137))
  incl = 'if'(excludeCenter, sapply(idx, function(x) which(dMat[x,] <= radius  & idx!=x)),
              sapply(idx, function(x) which(dMat[x,] <= radius)))

  cols = rep("Black", N)
  cols[incl[[chosenEntry]]] = "Blue"
  cols[chosenEntry] = 'if'(excludeCenter, "Black", "Red")
  main = c(paste("Chosen:", chosenEntry),
           paste("Exclude Center:", excludeCenter),
           paste("Nval=", length(incl[[chosenEntry]])))
  plot(Coords, pch=16, col= cols, main=main)
  points(Coords[chosenEntry,, drop=F], pch=21, bg=cols[chosenEntry], col="Black", cex=1.25)
}
