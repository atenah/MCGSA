
#' "Moving Grid Circulat Spatial Adjustment"
#'\author{
#'  Atena Haghighattalab}
#' This is a function that, returns an adjusted phenotype value as described
#' in the vignette to the mvngGrAd package with a modification in a way that
#' it uses a defined radius instead of number of neighbours to be considered
#' in the moving grid.
#'
#'\usage{
#'mcsa(Coords, obsPhe, radius, excludeCenter = T)
#'}
#' @param Coords The coordinates of plots, in longitude and altitude format
#' @param obsPhe The phenotyping observation
#' @param radius Defined radius in meter to draw the circular moving grid
#'
#' @return Returns an adjusted phenotype value
#'
#' @examples
#' library(MCGSA)
#'dat = read.delim()
#'Coords  = cbind(Long = dat$Long, Lat = dat$LAT)
#'obsPhe  = dat$Yield
#'res = mcsa(Coords = Coords, obsPhe = obsPhe, radius = 5, excludeCenter = T)
#'
#' @export

mcsa <- function(Coords, obsPhe, radius, excludeCenter=TRUE){
  N    = nrow(Coords)
  idx  = 1:N
  dMat = sapply(idx, function(x) distHaversine(Coords, Coords[x,], r = 6378137))
  incl = 'if'(excludeCenter, sapply(idx, function(x) which(dMat[x,] <= radius  & idx!=x)),
              sapply(idx, function(x) which(dMat[x,] <= radius)))

  xi   = sapply(idx, function(x) mean(obsPhe[incl[[x]]]))
  nVal = sapply(incl, length)

  b      = coef(lm(obsPhe ~ xi, na.action = "na.exclude"))[2]
  adjPhe = obsPhe - b*(xi - mean(xi, na.rm=T))
  ret    = cbind(Coords,
                 adjustedPhe = adjPhe,
                 observedPhe = obsPhe,
                 movingMean  = xi,
                 nValues     = nVal)
  return(ret)
}
